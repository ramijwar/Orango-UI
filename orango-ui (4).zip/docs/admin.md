# Orango Admin وRBAC

تقدم صفحة `examples/admin/index.html` نموذجاً متكاملاً للوحة الإدارة. وهي واجهة Frontend قابلة للربط مع أي Backend، وليست نظام حماية بحد ذاته؛ يجب تنفيذ التحقق من الصلاحيات على الخادم في كل طلب.

## الأقسام

تتكون اللوحة من ملخص مؤشرات، إدارة المستخدمين، مصفوفة الأدوار والصلاحيات، إدارة محتوى الأقسام، وسجل النشاط. لا يظهر رابط لوحة الإدارة في شريط التنقل العام. في التطبيق الحقيقي يوضع الرابط داخل قائمة المستخدم بعد أن يتحقق الخادم من أن المستخدم يملك `admin.access`.

## نموذج الصلاحيات

استخدم أسماء بصيغة `resource.action` مثل `store.read` و`news.approve` و`users.update`. الأدوار المقترحة هي `super_admin` و`content_manager` و`editor` و`support` و`viewer`. لا تعتمد على إخفاء الزر في الواجهة للحماية؛ الواجهة تتكيف مع الصلاحيات، لكن الخادم يرفض الطلب غير المصرح به.

## عقد API مقترح

| المسار | الطريقة | الغرض |
|---|---:|---|
| `/api/admin/me` | GET | المستخدم الحالي وصلاحياته |
| `/api/admin/users` | GET/POST | قائمة المستخدمين وإنشاء مستخدم |
| `/api/admin/users/:id` | PATCH/DELETE | تعديل أو تعطيل مستخدم |
| `/api/admin/roles` | GET/POST | إدارة الأدوار |
| `/api/admin/roles/:id/permissions` | PUT | حفظ مصفوفة الصلاحيات |
| `/api/admin/content` | GET/POST | جلب وإضافة محتوى الأقسام |
| `/api/admin/content/:id` | PATCH/DELETE | تعديل أو حذف المحتوى |
| `/api/admin/audit` | GET | سجل النشاط |

تكون استجابة القوائم بصيغة `{items, page, pages, total}`، وتكون أخطاء الصلاحيات بصيغة HTTP `403` مع `{error, code}`. يجب تسجيل عمليات إنشاء الأدوار، تغيير الصلاحيات، الحذف، الاعتماد، وتسجيل الدخول في سجل التدقيق.

## ربط الواجهة بالـAJAX

```js
const me = await OrangoAjax.get('/api/admin/me');
if (!me.permissions.includes('admin.access')) {
  location.replace('/403.html');
}

await OrangoAjax.loadList(
  document.querySelector('#contentRows'),
  '/api/admin/content',
  {section: 'news', page: 1},
  data => data.items.map(renderContentRow).join('')
);
```

حفظ تغيير صلاحية:

```js
await OrangoAjax.post('/api/admin/roles/editor/permissions', {
  permission: 'news.approve',
  allowed: true
});
```

توصى حماية API بجلسة HttpOnly أو OAuth، وCSRF token لطلبات التعديل، والتحقق من المدخلات، والتقسيم الصفحي، وتسجيل `actor_id` و`ip` و`user_agent` في سجل التدقيق.
