# Orango UI — كتالوج المكوّنات

## 1. الحاويات والبطاقات

```html
<div class="or-wrap"><section class="or-card">محتوى البطاقة</section></div>
<div class="or-grid or-grid-2"><article class="or-card">A</article><article class="or-card">B</article></div>
```

استخدم `or-card--flush` عندما يكون الجدول أو الصورة ممتداً حتى حافة البطاقة. استخدم `or-stack` عندما تحتاج مسافات رأسية منتظمة.

## 2. كل أنواع حقول البيانات

| النوع | التركيب |
|---|---|
| نص | `<input class="or-input" type="text">` |
| بريد | `<input class="or-input" type="email">` |
| رقم | `<input class="or-input" type="number" min="0">` |
| تاريخ | `<input class="or-input" type="date">` |
| وقت | `<input class="or-input" type="time">` |
| تاريخ ووقت | `<input class="or-input" type="datetime-local">` |
| كلمة مرور | `<input class="or-input" type="password">` |
| هاتف | `<input class="or-input" type="tel">` |
| رابط | `<input class="or-input" type="url">` |
| بحث | غلّف `input type="search"` داخل `.or-search` |
| اختيار مفرد | `<select class="or-select"><option>...</option></select>` |
| اختيار متعدد | `<select class="or-select" multiple>` |
| نص طويل | `<textarea class="or-textarea"></textarea>` |
| ملف | `<input class="or-input" type="file">` |
| checkbox | `<input type="checkbox">` مع `label` واضح |
| radio | مجموعة `input type="radio"` بنفس `name` |
| نطاق | `<input class="or-input" type="range">` |
| مخفي | `<input type="hidden">` دون تنسيق بصري |

النمط الموصى به للحقل هو:

```html
<label class="or-field">
  <span class="or-label">اسم الحقل</span>
  <input class="or-input" required aria-describedby="help-name">
  <span class="or-help" id="help-name">وصف قصير أو شرط الإدخال.</span>
</label>
```

للحالة غير الصحيحة أضف `aria-invalid="true"` وصنفاً مخصصاً في مشروعك يغيّر الحد إلى لون الخطأ. لا تستخدم `placeholder` بديلاً عن label.

## 3. الأزرار والأيقونات

```html
<button class="or-btn or-btn--primary">حفظ</button>
<button class="or-btn or-btn--soft">إجراء ثانوي</button>
<button class="or-btn or-btn--outline">رجوع</button>
<button class="or-btn or-btn--ghost">إلغاء</button>
<button class="or-btn or-btn--danger">حذف</button>
<button class="or-icon-btn" aria-label="إعدادات">⚙</button>
```

يدعم الإطار الأيقونات النصية أو SVG أو مكتبة خارجية. يجب أن يحمل زر الأيقونة `aria-label`.

## 4. التبويبات والقوائم

```html
<div class="or-tabs" role="tablist">
  <button class="or-tab is-active" role="tab" aria-selected="true">الكل</button>
  <button class="or-tab" role="tab" aria-selected="false">النشط</button>
</div>
```

فعّل التفاعل عبر `Orango.tabs(root, callback)`. القائمة الجانبية تستخدم `.or-sidebar` و`.or-nav`، والشريط السفلي يستخدم `.or-bottom-nav` ويظهر تلقائياً على الهاتف.

## 5. الإحصاءات والبادجات

```html
<div class="or-stat"><strong>1,280</strong><span>إجمالي السجلات</span></div>
<span class="or-badge">جديد</span>
<span class="or-badge or-badge--success">مكتمل</span>
<span class="or-badge or-badge--warning">مراجعة</span>
<span class="or-badge or-badge--danger">خطأ</span>
```

## 6. الجداول والقوائم

```html
<table class="or-table is-responsive">
  <thead><tr><th>الاسم</th><th>الحالة</th></tr></thead>
  <tbody><tr><td data-label="الاسم">أحمد</td><td data-label="الحالة">نشط</td></tr></tbody>
</table>
```

استخدم `or-table-wrap` حول الجدول للسماح بالتمرير الأفقي. في الهاتف، يقرأ CSS قيمة `data-label` ويعرضها بجانب كل قيمة.

## 7. الحالات

الحالة الفارغة:

```html
<div class="or-empty"><p>لا توجد نتائج مطابقة.</p></div>
```

التنبيه:

```html
<div class="or-alert or-alert--accent">تم حفظ البيانات بنجاح.</div>
```

التحميل: أضف `<span class="or-spinner" aria-label="جار التحميل"></span>`. الرسالة المؤقتة: `Orango.toast('تم الحفظ','accent')`. النافذة: `Orango.modal('<h2>تأكيد العملية</h2>')`.

## 8. مثال AJAX كامل

```html
<input id="q" class="or-input" type="search" placeholder="ابحث">
<div id="results" class="or-card"></div>
<script>
OrangoAjax.bindSearch(document.querySelector('#q'), {
  url: '/api/search.php',
  render: data => {
    document.querySelector('#results').textContent = `${data.found} نتيجة`;
  }
});
</script>
```

## 9. التصميم بدون أيقونات

جميع المكونات تعمل دون أيقونات. اجعل الأيقونة تحسيناً اختيارياً، لا جزءاً ضرورياً من معنى الزر. استخدم نصاً واضحاً مثل «حفظ» و«بحث» عندما يكون ذلك أكثر مباشرة.

## 10. التخصيص

```css
:root {
  --orange-accent: #2F7C6B;
  --orange-accent-deep: #205C4E;
  --orange-radius: 12px;
}
```

يُنصح بتغيير المتغيرات فقط في طبقة المشروع، وعدم تعديل الملف الأصلي، لتسهيل الترقية.


## 11. قسم المتاجر وتبويبات المتجر

يستخدم قسم المتجر `or-store-tabs` لتقسيم المنتجات إلى الكل، الجديد، العروض، والمفضلة. يحافظ على نفس ألوان Orango ويقبل أي محتوى داخلي مثل بطاقات المنتجات أو القوائم.

```html
<div class="or-store-tabs" role="tablist" aria-label="تبويبات المتجر">
  <button class="or-store-tab is-active" data-store="all" role="tab" aria-selected="true">الكل <span class="or-store-count">24</span></button>
  <button class="or-store-tab" data-store="offers" role="tab" aria-selected="false">العروض</button>
</div>
<div class="or-store-grid">
  <article class="or-card or-product-card">
    <div class="or-product-media">صورة المنتج</div>
    <div class="or-product-body"><h3 class="or-product-title">اسم المنتج</h3><div class="or-product-price">35,000 د.ع</div></div>
  </article>
</div>
<script>Orango.storeTabs(document.querySelector('.or-store-tabs'), key => loadProducts(key));</script>
```

## 12. الزر العائم والقائمة العائمة

الزر العائم مناسب للإجراء الرئيسي المتكرر مثل إضافة منتج أو فتح سلة الشراء. القائمة تظهر بحركة قصيرة ولا تعتمد على مكتبة خارجية.

```html
<button id="storeFab" class="or-fab" aria-label="فتح الإجراءات" aria-expanded="false">＋</button>
<div id="storeFabMenu" class="or-fab-menu">
  <a href="#add">＋ إضافة منتج</a>
  <a href="#orders">▣ إدارة الطلبات</a>
</div>
<script>Orango.fab(document.querySelector('#storeFab'), document.querySelector('#storeFabMenu'));</script>
```

يمكن تعطيل الحركة تلقائياً للمستخدمين الذين يفضلون تقليل الحركة بفضل `prefers-reduced-motion`.

## 13. Spinner وLoading overlay

```html
<span class="or-spinner" aria-label="جار التحميل"></span>
<div class="or-loading or-card"><span class="or-spinner"></span>جاري تحميل البيانات</div>
```

أضف `or-loading` إلى البطاقة أو الحاوية التي تنتظر استجابة AJAX. يجب إزالة الصنف بعد اكتمال الطلب.

## 14. Skeleton loading

يستخدم Skeleton لحجز المساحة قبل وصول البيانات ومنع قفز تخطيط الصفحة.

```html
<div class="or-skeleton or-skeleton--media"></div>
<div class="or-skeleton or-skeleton--title"></div>
<div class="or-skeleton or-skeleton--text"></div>
```

لإنشاء مجموعة بطاقات هيكلية عبر JavaScript استخدم `Orango.skeleton(container, 6)` ثم استبدل محتواها عند اكتمال الطلب.

## 15. Lazy loading

```html
<img class="or-lazy" data-src="images/product.webp" alt="اسم المنتج">
<div class="or-lazy or-skeleton or-skeleton--media"></div>
<script>Orango.lazy();</script>
```

يراقب الإطار العناصر قبل دخولها الشاشة بمسافة `120px`. الصور التي تحمل `data-src` تُنقل إلى `src` عند الحاجة، والعناصر العادية تحصل على `is-loaded`. يستخدم الإطار `IntersectionObserver`، ومع المتصفحات القديمة يزيل حالة الإخفاء تلقائياً.

## 16. شريط المتجر السفلي

يمكن إعادة استخدام `.or-bottom-nav`، مع تخصيص رابط المتجر:

```html
<nav class="or-bottom-nav">
  <a href="/">⌂<br>الرئيسية</a>
  <a class="is-active" href="/store">▣<br>المتجر</a>
  <a href="/cart">▢<br>السلة</a>
  <a href="/account">◉<br>حسابي</a>
</nav>
```

يظهر الشريط على الشاشات الصغيرة افتراضياً. إذا أردت ظهوره دائماً، غيّر `display` في طبقة مشروعك.


## 17. حزمة المتجر الكاملة

يحتوي `examples/storefront.html` على معرض تطبيقي يجمع الأنماط التالية في صفحة واحدة:

| المنطقة | المكونات |
|---|---|
| واجهة المتجر | Promo banner، شعار المتجر، المفضلة، السلة |
| صفحة التصنيف | فلاتر، chips للفلاتر المطبقة، ترتيب، عرض شبكي/قائمة |
| المنتج | بطاقة منتج، صورة، سعر قديم، خصم، تقييم، عرض سريع، مفضلة |
| صفحة التفاصيل | معرض صور، صور مصغرة، مواصفات، كمية، إضافة للسلة |
| السلة | عناصر السلة، تغيير الكمية، ملخص، تكلفة الشحن، الإجمالي |
| الدفع | Stepper، بيانات العميل، العنوان، طريقة الدفع |
| الطلبات | Badge للحالة، Timeline لتتبع الشحن |
| الثقة | مراجعات، تقييم نجمي، حالات توفر المنتج |

## 18. الفلاتر والفرز

في سطح المكتب يظهر `or-filter-panel` كلوحة جانبية ثابتة. في الهاتف يتحول إلى Bottom Sheet عبر `Orango.filterDrawer`. يُفضّل وضع أهم الفلاتر مفتوحة مثل السعر والتوفر، وإخفاء الأقل أهمية داخل `details` مغلق. اعرض عدد النتائج بجانب كل اختيار، وأظهر الفلاتر المطبقة كـ `or-chip` يمكن حذفها بشكل مستقل.

```html
<button id="openFilters" class="or-btn or-btn--outline or-mobile-filter-trigger">☷ الفلاتر</button>
<aside id="filters" class="or-card or-filter-panel">...</aside>
<script>Orango.filterDrawer(filters, openFilters, closeFilters);</script>
```

يجب فصل **البحث** عن **الفلترة** وعن **الفرز**: البحث يعثر بالكلمة، الفلترة تضيق النتائج بالخصائص، والفرز يعيد ترتيب النتائج. على الهاتف استخدم زر «عرض X نتيجة» بعد اختيار الفلاتر.

## 19. بطاقة المنتج

تتكون البطاقة من مساحة صورة، نوع أو تصنيف، اسم، تقييم، سعر، سعر قديم، وحالتي «أضف للسلة» و«مفضلة». لا تجعل زر العرض السريع هو الإجراء الوحيد؛ يجب أن تبقى المعلومات الأساسية مرئية دون تحويم على الهاتف.

```html
<article class="or-card or-product-card">
  <div class="or-product-media or-product-media--wide">...</div>
  <div class="or-product-body">
    <div class="or-product-meta"><span>الفئة</span><span class="or-rating">★★★★★</span></div>
    <h3 class="or-product-title">اسم المنتج</h3>
    <div class="or-product-price">35,000 د.ع <span class="or-old-price">42,000</span></div>
    <div class="or-product-actions"><button class="or-btn or-btn--primary">أضف للسلة</button><button class="or-icon-btn" aria-label="المفضلة">♡</button></div>
  </div>
</article>
```

## 20. السلة والكمية

استخدم `or-cart-layout` لعرض العناصر بجانب الملخص على سطح المكتب. يتكدس التخطيط على الهاتف. يرتبط عداد الكمية بالدالة `Orango.quantity(root, onChange)`، بينما توفر `Orango.cart` ذاكرة بسيطة للعرض التجريبي؛ في الإنتاج يجب حفظ السلة في الخادم أو في حالة التطبيق.

## 21. الدفع والطلبات

استخدم `or-stepper` عندما تكون عملية الدفع متعددة المراحل، ولا تعرض كل الحقول دفعة واحدة على الهاتف. استخدم `or-timeline` لتتبع الطلب، و`or-order-status` أو `or-badge--success` للحالة الحالية. يجب أن يكون إجمالي الطلب وتكلفة الشحن واضحين قبل زر الإتمام.

## 22. مراجع أنماط التصميم

تمت مراجعة تصنيف مكونات التجارة الإلكترونية في Tailwind UI، ويتضمن صفحات المنتج والقوائم والتصنيفات والسلات والفلاتر والعرض السريع والتنقل والترويج ونماذج الدفع والمراجعات وملخص الطلب وسجل الطلبات.[1] كما روجعت إرشادات Baymard للفلترة، والتي تؤكد دعم خيارات متعددة داخل نوع الفلتر، إظهار عدد النتائج، إبقاء الفلاتر المطبقة مرئية، واستخدام لوحة أو Bottom Sheet مع زر تطبيق واضح على الهاتف.[2] وتمت مراجعة Shopify Polaris كمرجع لنظام موحد متعدد الأسطح داخل واجهات الإدارة والدفع والحسابات ونقاط البيع.[3]

[1]: https://tailwindcss.com/plus/ui-blocks/ecommerce "Tailwind UI Ecommerce components and page examples"
[2]: https://baymard.com/learn/ecommerce-filter-ui "Baymard Ecommerce Filter UI best practices"
[3]: https://shopify.dev/docs/api/polaris "Shopify Polaris references and app surfaces"


## 23. شارات المتجر وحالات الرسائل

الشارات لا تعتمد على اللون وحده، بل تحتوي على نص يوضح المعنى. الأنواع التجارية الجاهزة هي:

```html
<span class="or-badge or-badge--offer">عرض خاص</span>
<span class="or-badge or-badge--verified">✓ موثق</span>
<span class="or-badge or-badge--favorite">♡ مفضل</span>
<span class="or-badge or-badge--report">⚑ تم الإبلاغ</span>
<span class="or-badge or-badge--success">متوفر</span>
<span class="or-badge or-badge--warning">مراجعة</span>
<span class="or-badge or-badge--danger">منتهي</span>
<span class="or-badge or-badge--info">معلومة</span>
```

رسائل الحالة:

```html
<div class="or-alert or-alert--success">تمت العملية بنجاح.</div>
<div class="or-alert or-alert--danger">فشلت العملية، حاول مرة أخرى.</div>
<div class="or-alert or-alert--warning">تحقق من البيانات قبل المتابعة.</div>
<div class="or-alert or-alert--accent">معلومة مهمة للمستخدم.</div>
```

## 24. قواعد منع تمدد الصفحة

استخدم `min-width: 0` لعناصر الشبكة والبطاقات، و`max-width: 100%` للحقول، ولا تضع عناصر بعرض ثابت داخل `.or-grid`. يتضمن الملف الأساسي إصلاحات عامة لـ `html` و`body` و`.or-card` و`.or-field` وحقول الإدخال حتى لا يخرج النص أو الحقل من الحاوية. للصور استخدم `width:100%;height:100%;object-fit:cover` داخل `.or-product-media`.

على الهاتف يستخدم `.or-wrap` عرضاً محسوباً مع هامش 12px، وتضيف `.or-bottom-nav` مساحة آمنة أسفل الشاشة عبر `env(safe-area-inset-bottom)`.

## 25. الشريط السفلي للمتجر

استخدم بنية ثابتة تحتوي على أيقونة ونص قصير، وأضف `is-active` للرابط الحالي. يجب ألا يعتمد الشريط على `position: static` في التطبيق النهائي؛ المثال في فهرس الصفحات يستخدم الوضع الثابت لأنه يعرض الفهرس داخل بطاقة، بينما الصفحات الفعلية تستخدم الشريط المثبت.

```html
<nav class="or-bottom-nav">
  <a href="home.html"><span class="or-nav-icon">⌂</span>الرئيسية</a>
  <a class="is-active" href="products.html"><span class="or-nav-icon">▣</span>المتجر</a>
  <a href="cart.html"><span class="or-nav-icon">▢</span>السلة</a>
  <a href="orders.html"><span class="or-nav-icon">◷</span>طلباتي</a>
</nav>
```

فعّل الحالة برمجياً عند الحاجة عبر `Orango.bottomNav(root)`.


## 26. المكونات العامة للمجالات

### التوصيل

يستخدم قسم التوصيل `or-timeline-horizontal` لمراحل الشحنة، و`or-map-placeholder` لمساحة الخريطة، و`or-driver-card` لبيانات السائق، و`or-avatar` للصورة المختصرة. يمكن تحويل خط المراحل إلى خط رأسي على الهاتف أو استخدام `or-timeline` التفصيلي.

### التعليم

يستخدم قسم التعليم `or-course-card` لبطاقات الدورات، و`or-progress` للتقدم، و`or-lesson-list` و`or-lesson` للدروس، و`or-certificate` للشهادات. لا تربط التقدم باللون فقط؛ اعرض النسبة والنص مثل «72% مكتمل».

### الأخبار

يستخدم قسم الأخبار `or-breaking` لشريط الأخبار العاجلة، و`or-news-card` و`or-news-media` للبطاقات، و`or-feed` و`or-feed-item` للتغذية، و`or-news-meta` للمصدر والوقت. صفحة المقال تستخدم عرضاً مريحاً للنص، وحالات الحفظ والمشاركة والإبلاغ.

### مؤشرات ولوحات البيانات

```html
<div class="or-kpi"><strong>68%</strong><small>التقدم العام</small></div>
<div class="or-progress"><span style="width:68%"></span></div>
<div class="or-stat"><strong>1,248</strong><span>شحنة اليوم</span></div>
```

### تفعيل التقدم والفلترة

```js
Orango.progress(document.querySelector('.or-progress'), 72);
Orango.liveFilter(input, document.querySelectorAll('.or-news-card'), emptyState);
Orango.activateLinks();
```

## 27. مبدأ بنية الإطار

يتكون Orango UI من ثلاث طبقات. الطبقة الأولى هي الأساس العام، وتشمل المتغيرات، الحاويات، البطاقات، النماذج، الأزرار والحالات. الطبقة الثانية هي التفاعلات المشتركة مثل التبويبات، AJAX، الشريط السفلي، الفلاتر، التحميل والرسائل. الطبقة الثالثة هي أنماط المجالات، مثل بطاقات المنتج أو خط الشحنة أو بطاقة الخبر. بهذا الأسلوب يمكن استخدام الإطار لتطبيق جديد دون تحميل مفهوم المتجر أو التوصيل إذا لم يكن مطلوباً.


## 28. إصلاح احتواء النماذج والـSpinner

سبب خروج الحقول عن الجدول أو البطاقة هو أن عناصر النموذج قد تملك `min-width` أو عرضاً داخلياً أكبر من الخلية، خصوصاً مع الشبكات وحقول `select` و`textarea` وحقول البحث. لذلك يفرض الإصدار الحالي `min-width:0` و`max-width:100%` على الخلية والحقل وعنصر النموذج، ويجعل الحقول `display:block` بعرض كامل.

السبب الشائع لعدم عمل Spinner هو استخدامه كعنصر inline أو وضعه داخل حاوية لا تملك `position:relative`، أو تشغيله دون حالة `aria-busy`. يوفر الإطار الآن API موحداً:

```js
await Orango.withLoading(document.querySelector('#results'), async () => {
  const data = await OrangoAjax.get('/api/items.php');
  render(data);
});
```

أو يدوياً:

```js
Orango.loading('#saveCard', true);
// بعد انتهاء الطلب
Orango.loading('#saveCard', false);
```

ويمكن تغيير حجمه عبر `or-spinner--sm` أو `or-spinner--lg`. لا تضع Spinner داخل جدول إلا في خلية تحتويه، ولا تستخدم `position:absolute` يدوياً بعد الآن؛ الحاوية `.or-loading` تتولى الطبقة والتمركز.


## 29. القوائم المنسدلة المخصصة

القائمة الأصلية `<select>` مناسبة للبيانات البسيطة، لكن Orango UI يوفر قائمة مخصصة بنفس الهوية البصرية حتى لا تظهر قائمة النظام. تدعم القائمة الاختيار المفرد، الاختيار المتعدد، والبحث الفوري داخل الخيارات.

```html
<div class="or-dropdown" data-dropdown>
  <button class="or-dropdown-toggle" type="button" aria-expanded="false">
    <span data-dropdown-label>اختر القسم</span><span class="or-dropdown-chevron">⌄</span>
  </button>
  <div class="or-dropdown-menu">
    <button class="or-dropdown-option" type="button" data-value="shop" data-label="المتاجر">المتاجر</button>
    <button class="or-dropdown-option" type="button" data-value="news" data-label="الأخبار">الأخبار</button>
  </div>
</div>
<script>Orango.dropdown(document.querySelector('[data-dropdown]'));</script>
```

للاختيار المتعدد أضف `multiple:true`، وللبحث أضف `search:true` وحقل `.or-dropdown-search` داخل القائمة. يجب أن تكون الخيارات أزراراً حقيقية مع `aria-selected`، ولا يعتمد المكوّن على قوائم النظام.

## 30. رسائل الحالة

يحتوي الإطار على `or-alert--success` للنجاح، و`or-alert--danger` للفشل، و`or-alert--warning` للتنبيه، و`or-alert--accent` للمعلومة. كما يدعم `Orango.toast(message, type)` للرسائل المؤقتة. صفحة العرض العملية هي `examples/components.html`.

## 31. خط الرموز

الملف `css/orango-icons.css` يضيف خط **Material Symbols Rounded**، بينما يستخدم الصنف `or-icon` أسماء الرموز مثل `home` و`search` و`shopping_cart` و`local_shipping` و`school`. تحميل الخط اختياري؛ يمكن استبداله بـ SVG أو مكتبة رموز محلية دون تغيير بنية المكونات.


## 32. مركز الإشعارات

يستخدم الجرس `.or-bell` مع `.or-notify-bubble` لعرض عدد الإشعارات غير المقروءة، وتوضع القائمة داخل `.or-notify-menu`. أضف `is-unread` للإشعارات الجديدة. على الهاتف تتحول القائمة إلى لوحة مثبتة بعرض الشاشة تقريباً.

## 33. المحادثة

يتكون قسم المحادثة من `.or-chat-layout` و`.or-chat-list` و`.or-chat-main`. استخدم `.or-message` للرسائل الواردة، وأضف `is-own` لرسائل المستخدم الحالي. يفضل إرسال نموذج المحادثة عبر `OrangoAjax.post` مع تحديث الرسائل وإظهار Spinner أثناء الإرسال.

## 34. نظام العضوية

يستخدم `.or-plan-grid` و`.or-plan` للباقات، و`is-featured` للباقـة الموصى بها، و`.or-plan-features` للمزايا، و`.or-membership-bar` لملخص الحساب، و`.or-role-badge` للصلاحيات والأدوار.

## 35. AJAX المتقدم

توفر طبقة `js/orango-ajax.js` الوظائف التالية:

| الدالة | الاستخدام |
|---|---|
| `request` | طلب عام مع JSON ورؤوس AJAX |
| `get` | جلب بيانات مع query parameters |
| `post` | إرسال JSON إلى API |
| `fillSelect` | تعبئة قائمة HTML من مصفوفة خيارات |
| `loadOptions` | جلب خيارات قائمة من API مع حالة تحميل |
| `loadForm` | جلب بيانات وتعبئة حقول نموذج |
| `submitForm` | إرسال `FormData` مع success/error |
| `loadList` | جلب قائمة وإعادة رسمها |
| `bindSearch` | بحث مؤجل Debounced |

مثال قائمة تعتمد على قائمة أخرى:

```js
province.addEventListener('change', async () => {
  await OrangoAjax.loadOptions(city, '/api/cities.php', {
    province: province.value
  });
});
```

مثال نموذج كامل:

```js
await OrangoAjax.submitForm(form, '/api/profile-save.php', {
  onSuccess: data => Orango.toast(data.message, 'success'),
  onError: () => Orango.toast('تعذر حفظ النموذج', 'danger')
});
```

مثال قائمة ديناميكية مع رسم مخصص:

```js
await OrangoAjax.loadList(
  results,
  '/api/orders.php',
  {page: 1, status: 'active'},
  data => data.items.map(renderOrder).join('')
);
```

كل عمليات الجلب داخل `loadOptions` و`loadForm` و`submitForm` و`loadList` تستخدم `Orango.withLoading`، ولذلك تظهر حالة التحميل داخل الحاوية وتزال في `finally` حتى عند الفشل.


## 36. مرجع AJAX الكامل

يوجد الدليل الشامل في `docs/ajax.md`، ويتضمن أمثلة ربط النماذج والقوائم ديناميكياً، نمط استجابة API، التعامل مع حالات التحميل والأخطاء، الحماية، والإلغاء.
