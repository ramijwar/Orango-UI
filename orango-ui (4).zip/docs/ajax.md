# توثيق نظام Orango AJAX

**الإصدار:** Orango UI 1.x  
**الجمهور المستهدف:** مطورو الواجهات الأمامية والخلفية  
**الملف الأساسي:** `js/orango-ajax.js`

## 1. مقدمة

يوفر Orango AJAX طبقة صغيرة قابلة لإعادة الاستخدام فوق `fetch` لجلب البيانات وإرسالها دون إعادة تحميل الصفحة. تعالج الطبقة إضافة رؤوس الطلب، بناء معاملات GET، إرسال JSON في POST، البحث المؤجل، حالة التحميل، تعبئة القوائم، تعبئة النماذج، وإعادة رسم القوائم.

> طبقة AJAX ليست بديلاً عن حماية الخادم. يجب أن يتحقق الخادم من الجلسة والصلاحيات وصحة البيانات في كل طلب، حتى لو كانت الواجهة تمنع الزر أو تخفيه.

لتحميلها، يجب تحميل Orango UI ثم طبقة AJAX:

```html
<link rel="stylesheet" href="/css/orango-ui.css">
<script src="/js/orango-ui.js"></script>
<script src="/js/orango-ajax.js"></script>
```

بعد التحميل تصبح الواجهة متاحة عبر:

```js
OrangoAjax
```

## 2. شكل الاستجابة الموصى به

يفضل أن يعيد الخادم JSON مع `Content-Type: application/json`. للاستجابات الناجحة استخدم شكلاً ثابتاً يسهل على الواجهة التعامل معه.

| العملية | الاستجابة المقترحة |
|---|---|
| قائمة | `{ "items": [], "total": 0, "page": 1, "pages": 1 }` |
| عنصر واحد | `{ "item": { ... } }` |
| حفظ | `{ "ok": true, "message": "تم الحفظ", "item": { ... } }` |
| خطأ تحقق | HTTP 422 مع `{ "error": "بيانات غير صالحة", "fields": { ... } }` |
| غير مصرح | HTTP 401 أو 403 مع `{ "error": "غير مصرح" }` |
| خطأ خادم | HTTP 500 مع `{ "error": "حدث خطأ داخلي" }` |

لا تعرض تفاصيل الاستثناءات أو stack trace للمستخدم. سجّلها في الخادم، وأرسل رسالة عامة إلى المتصفح.

## 3. `request`: الطلب العام

الدالة `request(url, options)` هي الأساس الذي تعتمد عليه بقية الدوال. تضيف تلقائياً:

- `Accept: application/json`.
- `X-Requested-With: XMLHttpRequest`.
- فحص `response.ok`.
- تحويل الاستجابة إلى JSON.

```js
try {
  const data = await OrangoAjax.request('/api/profile', {
    method: 'GET'
  });
  console.log(data);
} catch (error) {
  Orango.toast('تعذر الاتصال بالخادم', 'danger');
}
```

يمكن تمرير خيارات `fetch` المعتادة، مثل `signal` للإلغاء أو `credentials` للجلسات.

```js
const controller = new AbortController();
const timer = setTimeout(() => controller.abort(), 8000);

try {
  const data = await OrangoAjax.request('/api/report', {
    signal: controller.signal,
    credentials: 'same-origin'
  });
} finally {
  clearTimeout(timer);
}
```

## 4. `get`: جلب البيانات والمعاملات

تستقبل `get` عنواناً وكائن معاملات. تضاف المعاملات إلى عنوان URL مع ترميز آمن للقيم.

```js
const data = await OrangoAjax.get('/api/products', {
  page: 1,
  search: 'حقيبة',
  category: 'bags',
  per_page: 12
});
```

الطلب الناتج يكون قريباً من:

```text
/api/products?page=1&search=%D8%AD%D9%82%D9%8A%D8%A8%D8%A9&category=bags&per_page=12
```

استخدم `get` للقوائم والبيانات التي لا تغير حالة الخادم. لا تستخدمه لحفظ أو حذف البيانات.

## 5. `post`: إرسال JSON

ترسل `post` كائناً بصيغة JSON مع `Content-Type: application/json`.

```js
const result = await OrangoAjax.post('/api/orders', {
  product_id: 42,
  quantity: 2,
  address_id: 8
});

Orango.toast(result.message || 'تم إنشاء الطلب', 'success');
```

في الخادم يجب قراءة JSON من جسم الطلب، وليس من `$_POST` فقط. مثال PHP:

```php
<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
$payload = json_decode(file_get_contents('php://input'), true);

if (!is_array($payload)) {
    http_response_code(400);
    echo json_encode(['error' => 'صيغة الطلب غير صالحة'], JSON_UNESCAPED_UNICODE);
    exit;
}

$name = trim((string)($payload['name'] ?? ''));
if ($name === '') {
    http_response_code(422);
    echo json_encode(['error' => 'الاسم مطلوب'], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode([
    'ok' => true,
    'message' => 'تم الحفظ',
    'item' => ['name' => $name]
], JSON_UNESCAPED_UNICODE);
```

## 6. `formData`: تحويل النموذج إلى بيانات

تحول `formData(form)` الحقول إلى كائن JavaScript. تعتمد على أسماء الحقول، لذلك يجب أن يحمل كل حقل صالح للإرسال خاصية `name`.

```html
<form id="profileForm">
  <input name="name" value="سارة أحمد">
  <input name="email" type="email" value="sara@example.com">
  <select name="role">
    <option value="editor">محرر</option>
  </select>
</form>
```

```js
const form = document.querySelector('#profileForm');
const values = OrangoAjax.formData(form);
console.log(values);
// { name: 'سارة أحمد', email: 'sara@example.com', role: 'editor' }
```

لرفع ملفات، استخدم `FormData` الأصلي وطلباً مخصصاً، لأن `formData` المساعد الحالي يحول القيم إلى كائن بسيط ولا يحتفظ بملفات `File`.

```js
const body = new FormData(form);
await OrangoAjax.request('/api/avatar', {
  method: 'POST',
  body,
  headers: { Accept: 'application/json' }
});
```

لا تضف `Content-Type: multipart/form-data` يدوياً عند استخدام `FormData`. يضع المتصفح boundary الصحيح تلقائياً.

## 7. `fillSelect`: تعبئة قائمة موجودة

تملأ `fillSelect(select, items, options)` عنصر `<select>` من مصفوفة. الوضع الافتراضي يتوقع مفاتيح `id` و`name`.

```js
const select = document.querySelector('#category');
OrangoAjax.fillSelect(select, [
  { id: 1, name: 'متاجر' },
  { id: 2, name: 'تعليم' },
  { id: 3, name: 'أخبار' }
], {
  placeholder: 'اختر القسم'
});
```

لتغيير أسماء المفاتيح:

```js
OrangoAjax.fillSelect(select, data.items, {
  value: 'code',
  label: 'title',
  placeholder: 'اختر المدينة'
});
```

تقوم الدالة بتهريب النصوص قبل إدخالها إلى HTML. مع ذلك، يجب أن يرسل الخادم بيانات صحيحة ومحددة النوع.

## 8. `loadOptions`: قائمة ديناميكية

تجلب `loadOptions(select, url, params)` الخيارات من API، وتعطل القائمة أثناء الطلب، وتضيف حالة `or-loading` إلى الحقل، ثم تعيد تفعيلها في `finally` حتى عند حدوث خطأ.

مثال قائمة محافظة ومدن:

```html
<label class="or-field">
  <span class="or-label">المحافظة</span>
  <select id="province" class="or-select">
    <option value="">اختر المحافظة</option>
    <option value="baghdad">بغداد</option>
    <option value="basra">البصرة</option>
  </select>
</label>
<label class="or-field">
  <span class="or-label">المدينة</span>
  <select id="city" class="or-select">
    <option value="">اختر المدينة</option>
  </select>
</label>
```

```js
const province = document.querySelector('#province');
const city = document.querySelector('#city');

province.addEventListener('change', async () => {
  if (!province.value) {
    OrangoAjax.fillSelect(city, [], { placeholder: 'اختر المحافظة أولاً' });
    return;
  }

  try {
    await OrangoAjax.loadOptions(city, '/api/cities.php', {
      province: province.value
    });
  } catch (error) {
    Orango.toast('تعذر تحميل المدن', 'danger');
  }
});
```

استجابة PHP بسيطة:

```php
<?php
header('Content-Type: application/json; charset=utf-8');

$province = (string)($_GET['province'] ?? '');
$items = match ($province) {
    'baghdad' => [
        ['id' => 1, 'name' => 'الكرادة'],
        ['id' => 2, 'name' => 'المنصور'],
    ],
    'basra' => [
        ['id' => 3, 'name' => 'العشار'],
        ['id' => 4, 'name' => 'الزبير'],
    ],
    default => [],
};

echo json_encode(['items' => $items], JSON_UNESCAPED_UNICODE);
```

## 9. `loadForm`: تحميل بيانات نموذج

تجلب `loadForm(form, url, params)` بيانات النموذج وتطابق مفاتيح JSON مع `name` أو `id` عناصر النموذج.

```html
<form id="accountForm" class="or-card">
  <label class="or-field">
    <span class="or-label">الاسم</span>
    <input class="or-input" name="name">
  </label>
  <label class="or-field">
    <span class="or-label">البريد</span>
    <input class="or-input" name="email" type="email">
  </label>
  <label class="or-field">
    <span class="or-label">نبذة</span>
    <textarea class="or-textarea" name="bio"></textarea>
  </label>
</form>
```

```js
const accountForm = document.querySelector('#accountForm');

try {
  await OrangoAjax.loadForm(accountForm, '/api/account.php', { id: 42 });
  Orango.toast('تم تحميل بيانات الحساب', 'success');
} catch (error) {
  Orango.toast('تعذر تحميل الحساب', 'danger');
}
```

استجابة API:

```json
{
  "fields": {
    "name": "سارة أحمد",
    "email": "sara@example.com",
    "bio": "محررة محتوى"
  }
}
```

إذا احتاجت الواجهة إلى معالجة خاصة، مثل تحديد قائمة مخصصة أو تحميل صورة، نفذها بعد اكتمال `loadForm`.

## 10. `submitForm`: إرسال نموذج

ترسل `submitForm(form, url, options)` بيانات النموذج إلى الخادم وتغلف العملية بحالة تحميل. يدعم الخياران `onSuccess` و`onError`.

```js
const form = document.querySelector('#accountForm');

form.addEventListener('submit', async event => {
  event.preventDefault();

  try {
    await OrangoAjax.submitForm(form, '/api/account.php', {
      onSuccess: data => {
        Orango.toast(data.message || 'تم حفظ الحساب', 'success');
      },
      onError: () => {
        Orango.toast('تعذر حفظ الحساب', 'danger');
      }
    });
  } catch (error) {
    console.error(error);
  }
});
```

يفضل أن يعيد الخادم أخطاء الحقول بشكل واضح:

```json
{
  "error": "تحقق من الحقول",
  "fields": {
    "email": "البريد مستخدم مسبقاً"
  }
}
```

يمكن رسم أخطاء الحقول في الواجهة:

```js
function showFieldErrors(form, fields) {
  form.querySelectorAll('.or-field-error').forEach(x => x.remove());
  Object.entries(fields || {}).forEach(([name, message]) => {
    const input = form.elements[name];
    const field = input?.closest('.or-field');
    if (!field) return;
    input.setAttribute('aria-invalid', 'true');
    field.insertAdjacentHTML(
      'beforeend',
      `<span class="or-help or-field-error" style="color:#A83D35">${Orango.escape(message)}</span>`
    );
  });
}
```

## 11. `loadList`: جلب القوائم وإعادة رسمها

تستقبل `loadList(root, url, params, render)` حاوية وعنواناً ومعاملات ودالة رسم. تضع حالة تحميل على الحاوية، ثم تستبدل محتواها بالناتج.

```html
<section id="orders" class="or-card">
  <div class="or-empty">سيتم تحميل الطلبات</div>
</section>
```

```js
const orders = document.querySelector('#orders');

await OrangoAjax.loadList(
  orders,
  '/api/orders.php',
  { page: 1, status: 'active' },
  data => data.items.map(order => `
    <article class="or-order-row">
      <strong>${Orango.escape(order.number)}</strong>
      <span class="or-badge or-badge--success">
        ${Orango.escape(order.status_label)}
      </span>
      <span>${Orango.escape(order.total_label)}</span>
    </article>
  `).join('')
);
```

لا تدخل نصوص API في `innerHTML` دون تهريب. استخدم `Orango.escape` أو أنشئ عناصر DOM باستخدام `textContent`.

## 12. `bindSearch`: البحث المؤجل

تربط `bindSearch(input, options)` حقل بحث بطلب GET مؤجل زمنياً. التأجيل يمنع إرسال طلب عند كل حرف مباشرة.

```html
<div class="or-search">
  <span>⌕</span>
  <input id="productSearch" placeholder="ابحث عن منتج…">
</div>
<section id="productResults" class="or-card"></section>
```

```js
const input = document.querySelector('#productSearch');
const results = document.querySelector('#productResults');

OrangoAjax.bindSearch(input, {
  url: '/api/products.php',
  params: { per_page: 12 },
  render: data => {
    results.innerHTML = data.items.map(item => `
      <article class="or-card">
        <h3>${Orango.escape(item.name)}</h3>
        <p class="or-muted">${Orango.escape(item.category)}</p>
      </article>
    `).join('');
  }
});
```

تظهر حالة `is-loading` داخل أقرب عنصر `.or-search`. يمكن زيادة زمن التأجيل بإنشاء نسخة خاصة من `OrangoAjax.debounce`.

## 13. حالات التحميل والرسائل

لأي عملية لا يغطيها helper جاهز، استخدم `Orango.withLoading`:

```js
await Orango.withLoading(document.querySelector('#dashboard'), async () => {
  const data = await OrangoAjax.get('/api/dashboard');
  renderDashboard(data);
});
```

وللتحكم اليدوي:

```js
Orango.loading('#saveCard', true);
try {
  await OrangoAjax.post('/api/save', payload);
} finally {
  Orango.loading('#saveCard', false);
}
```

يجب أن تعرض الواجهة رسالة واضحة في الحالات التالية:

| الحالة | الإجراء |
|---|---|
| نجاح | Toast خضراء أو رسالة نجاح داخل البطاقة |
| تحقق غير صحيح | رسائل بجانب الحقول |
| انتهاء الجلسة | توجيه إلى تسجيل الدخول أو طلب التجديد |
| عدم الصلاحية | رسالة رفض دون كشف معلومات حساسة |
| فشل الشبكة | رسالة إعادة المحاولة |
| تحميل فارغ | Skeleton أو Spinner |
| نتيجة صفرية | حالة Empty واضحة |

## 14. الإلغاء ومنع الطلبات المتنافسة

في البحث السريع أو تغيير الفلاتر، قد تصل استجابة قديمة بعد الاستجابة الجديدة. استخدم `AbortController` أو رقم طلب متزايد.

```js
let controller;

async function searchProducts(query) {
  controller?.abort();
  controller = new AbortController();

  try {
    return await OrangoAjax.request('/api/products?q=' + encodeURIComponent(query), {
      signal: controller.signal
    });
  } catch (error) {
    if (error.name === 'AbortError') return null;
    throw error;
  }
}
```

## 15. الجلسات والحماية

في تطبيقات الجلسات على نفس النطاق، استخدم `credentials: 'same-origin'` إذا كانت إعدادات التطبيق تحتاج ذلك. في الطلبات العابرة للنطاق يجب ضبط CORS على الخادم وعدم استخدام `Access-Control-Allow-Origin: *` مع بيانات اعتماد.

احمِ طلبات التعديل والحذف من CSRF. يمكن تمرير رمز CSRF في رأس مخصص:

```js
await OrangoAjax.request('/api/profile', {
  method: 'PATCH',
  credentials: 'same-origin',
  headers: {
    'Content-Type': 'application/json',
    'X-CSRF-Token': window.CSRF_TOKEN
  },
  body: JSON.stringify({ name: 'سارة أحمد' })
});
```

يجب أن يفرض الخادم الصلاحيات على كل endpoint. وجود زر «حذف» مخفياً في الواجهة ليس حماية.

## 16. مثال تكامل كامل

يجمع المثال التالي قائمة قسم، نموذجاً تابعاً، وحفظاً مع نتائج واضحة:

```js
const section = document.querySelector('#section');
const category = document.querySelector('#category');
const form = document.querySelector('#articleForm');
const results = document.querySelector('#articles');

section.addEventListener('change', async () => {
  category.disabled = true;
  try {
    await OrangoAjax.loadOptions(category, '/api/categories.php', {
      section: section.value
    });
  } catch {
    Orango.toast('تعذر تحميل التصنيفات', 'danger');
  } finally {
    category.disabled = false;
  }
});

async function refreshArticles() {
  await OrangoAjax.loadList(
    results,
    '/api/articles.php',
    { section: section.value, category: category.value, page: 1 },
    data => data.items.map(article => `
      <article class="or-card">
        <h3>${Orango.escape(article.title)}</h3>
        <span class="or-faint">${Orango.escape(article.created_at)}</span>
      </article>
    `).join('')
  );
}

form.addEventListener('submit', async event => {
  event.preventDefault();
  try {
    await OrangoAjax.submitForm(form, '/api/articles.php', {
      onSuccess: async data => {
        Orango.toast(data.message || 'تم نشر المقال', 'success');
        form.reset();
        await refreshArticles();
      },
      onError: () => Orango.toast('تعذر نشر المقال', 'danger')
    });
  } catch (error) {
    console.error(error);
  }
});
```

## 17. صفحة العرض العملية

توجد أمثلة قابلة للتجربة في:

- `examples/ajax-advanced.html` لجلب القوائم وتعبئة النماذج والإرسال.
- `examples/admin/index.html` لتحديث مصفوفة الصلاحيات وإدارة المستخدمين والمحتوى.
- `examples/delivery/index.html` لتدفق التوصيل.
- `examples/education/index.html` لتدفق التعليم.
- `examples/news/index.html` لتدفق الأخبار.

تشغّل الأمثلة محلياً عبر:

```bash
cd orango-ui
python3 -m http.server 8080
```

ثم افتح `http://localhost:8080/examples/ajax-advanced.html`.

## 18. قائمة تحقق قبل الإنتاج

قبل نشر التكامل، تحقق من أن جميع الطلبات تستخدم HTTPS، وأن الخادم يتحقق من الصلاحيات، وأن المدخلات تهرب وتتحقق، وأن أخطاء 401 و403 و422 و500 تعالج بوضوح. اختبر انقطاع الشبكة، الاستجابة البطيئة، النتائج الفارغة، انتهاء الجلسة، التكرار، والضغط على زر الحفظ عدة مرات. سجّل العمليات الحساسة، ولا تضع الأسرار أو مفاتيح الإدارة في JavaScript.

## المراجع

[1]: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API "Fetch API - MDN Web Docs"
[2]: https://developer.mozilla.org/en-US/docs/Web/API/FormData "FormData - MDN Web Docs"
[3]: https://developer.mozilla.org/en-US/docs/Web/API/AbortController "AbortController - MDN Web Docs"
