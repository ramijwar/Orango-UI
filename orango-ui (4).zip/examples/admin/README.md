# Orango Admin Demo

افتح `index.html` لمعاينة لوحة الإدارة. المثال Frontend تجريبي؛ اربطه بـ API محمي على الخادم قبل الاستخدام الفعلي. راجع `../../docs/admin.md` لمخطط RBAC، عقد API، وأمثلة OrangoAjax.
