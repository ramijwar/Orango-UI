<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
$q = trim((string)($_GET['q'] ?? ''));
$items = [
    ['name' => 'أحمد محمد علي', 'status' => 'نشط'],
    ['name' => 'سليم حسن', 'status' => 'مراجعة'],
    ['name' => 'ليلى عبد الله', 'status' => 'مكتمل'],
];
$rows = array_values(array_filter($items, static fn(array $row): bool => $q === '' || mb_stripos($row['name'], $q) !== false));
echo json_encode(['rows' => $rows, 'found' => count($rows)], JSON_UNESCAPED_UNICODE);
