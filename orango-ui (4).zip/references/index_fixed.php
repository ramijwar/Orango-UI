<?php
declare(strict_types=1);

const DB_PATH = __DIR__ . '/prisoners.db';

const TABLES = [
    'all'                   => ['title' => 'كل السجلات',            'tables' => ['majalin','daesh_souriyin','daesh_muhajirin','daesh_iragiyyin','daesh_bakistaniyyin']],
    'majalin'               => ['title' => 'معتقلين',               'tables' => ['majalin']],
    'daesh_souriyin'        => ['title' => 'سوريين',         'tables' => ['daesh_souriyin']],
    'daesh_muhajirin'       => ['title' => 'مهاجرين',        'tables' => ['daesh_muhajirin']],
    'daesh_iragiyyin'       => ['title' => 'عراقيين',        'tables' => ['daesh_iragiyyin']],
    'daesh_bakistaniyyin'   => ['title' => 'باكستانيين',     'tables' => ['daesh_bakistaniyyin']],
];

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO('sqlite:' . DB_PATH, null, null, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $pdo->exec('PRAGMA journal_mode = MEMORY');
        $pdo->exec('PRAGMA synchronous = OFF');
    }
    return $pdo;
}


/** عداد الزيارات — يُحفظ في قاعدة البيانات ويُحتسب عند تحميل الصفحة فقط (لا عند طلبات API) */
function record_visit(): int {
    $pdo = db();
    $pdo->exec('CREATE TABLE IF NOT EXISTS site_stats ("key" TEXT PRIMARY KEY, "value" INTEGER NOT NULL DEFAULT 0)');
    $pdo->exec('INSERT OR IGNORE INTO site_stats ("key", "value") VALUES (\'visits\', 0)');
    $pdo->exec('UPDATE site_stats SET "value" = "value" + 1 WHERE "key" = \'visits\'');
    return (int) $pdo->query('SELECT "value" FROM site_stats WHERE "key" = \'visits\'')->fetchColumn();
}

/** بيانات وصفية: الأعمدة وعدد السجلات لكل جدول */
function meta(): array {
    $out = [];
    foreach (TABLES as $key => $cfg) {
        if ($key === 'all') continue;
        $cols = db()->query('PRAGMA table_info("' . $key . '")')->fetchAll();
        $count = (int) db()->query('SELECT COUNT(*) FROM "' . $key . '"')->fetchColumn();
        $out[$key] = [
            'title' => $cfg['title'],
            'columns' => array_values(array_filter(array_column($cols, 'name'), fn($c) => $c !== 'row_order')),
            'count' => $count,
        ];
    }
    $out['total'] = array_sum(array_column($out, 'count'));
    return $out;
}

/** بحث آمن: عبارة محضّرة + تهريب رموز LIKE */
function search(string $q, string $scope, int $limit = 500): array {
    $q = trim($q);
    $scopeCfg = TABLES[$scope] ?? TABLES['all'];
    $tables = $scope === 'all' ? TABLES['all']['tables'] : $scopeCfg['tables'];

    $like = '%' . str_replace(['%', '_'], ['\\%', '\\_'], $q) . '%';
    $rows = []; $t0 = microtime(true);

    foreach ($tables as $t) {
        $cols = array_values(array_filter(
            array_column(db()->query('PRAGMA table_info("' . $t . '")')->fetchAll(), 'name'),
            fn($c) => $c !== 'row_order'
        ));
        if (!$cols) continue;
        $where = implode(' OR ', array_map(fn($c) => '"' . $c . "\" LIKE ? ESCAPE '\\'", $cols));
        $sql = 'SELECT row_order, ' . implode(', ', array_map(fn($c) => '"' . $c . '"', $cols))
             . ' FROM "' . $t . '"' . ($q !== '' ? " WHERE $where" : '')
             . ' ORDER BY row_order LIMIT ' . (int)$limit;
        $stmt = db()->prepare($sql);
        $stmt->execute($q !== '' ? array_fill(0, count($cols), $like) : []);
        foreach ($stmt->fetchAll() as $r) {
            $rows[] = ['__table' => $t, '__row' => (int)$r['row_order']] + $r;
        }
        if (count($rows) >= $limit) { $rows = array_slice($rows, 0, $limit); break; }
    }
    return ['rows' => $rows, 'found' => count($rows), 'ms' => round((microtime(true) - $t0) * 1000, 1)];
}

/* ---------- واجهة البرمجة (JSON) ---------- */
if (isset($_GET['api'])) {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    try {
        if ($_GET['api'] === 'meta') {
            echo json_encode(meta(), JSON_UNESCAPED_UNICODE);
        } elseif ($_GET['api'] === 'search') {
            $q = isset($_GET['q']) ? (string)$_GET['q'] : '';
            $scope = isset($_GET['t']) ? (string)$_GET['t'] : 'all';
            if (!isset(TABLES[$scope])) $scope = 'all';
            echo json_encode(search(mb_substr($q, 0, 120), $scope), JSON_UNESCAPED_UNICODE);
        }
    } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['error' => 'خطأ في الخادم']);
    }
    exit;
}

/* عدّاد الزيارات: يُحتسب مرة واحدة عند كل تحميل للصفحة فقط */
$visits = record_visit();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>مساجين العراق</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{
    --bg:#F5F3EE; --surface:#FFFFFF; --surface-2:#FBFAF7;
    --ink:#1F1B16; --muted:#6F6558; --faint:#9A9084;
    --accent:#C96442; --accent-deep:#A94F31; --accent-soft:#F6E8E0;
    --border:#E7E1D6; --shadow:0 1px 2px rgba(31,27,22,.05),0 8px 24px -12px rgba(31,27,22,.12);
    --radius:16px;
}
*{margin:0;padding:0;box-sizing:border-box}
html{scroll-behavior:smooth}
body{
    font-family:'IBM Plex Sans Arabic',system-ui,sans-serif;
    background:var(--bg); color:var(--ink);
    min-height:100vh; line-height:1.7;
    background-image:radial-gradient(ellipse 80% 50% at 50% -10%, rgba(201,100,66,.06), transparent);
}
.wrap{max-width:1100px;margin:0 auto;padding:0 20px}

/* ===== الترويسة ===== */
header{padding:38px 0 26px}
.brand{display:flex;align-items:center;gap:14px}
.logo{
    width:52px;height:52px;border-radius:14px;flex-shrink:0;
    background:linear-gradient(135deg,var(--accent) 0%,var(--accent-deep) 100%);
    display:flex;align-items:center;justify-content:center;color:#fff;
    box-shadow:0 6px 18px -6px rgba(201,100,66,.5);
}
.logo svg{width:26px;height:26px}
.brand h1{font-size:clamp(22px,4vw,30px);font-weight:700;letter-spacing:-.3px}
.brand p{color:var(--muted);font-size:14px}

/* ===== البحث ===== */
.search-shell{margin:26px 0 8px;position:relative}
.search-box{
    background:var(--surface);border:1.5px solid var(--border);border-radius:var(--radius);
    display:flex;align-items:center;gap:12px;padding:6px 18px;
    box-shadow:var(--shadow);transition:border-color .25s, box-shadow .25s;
}
.search-box:focus-within{border-color:var(--accent);box-shadow:0 0 0 4px rgba(201,100,66,.12),var(--shadow)}
.search-box svg{width:22px;height:22px;color:var(--faint);flex-shrink:0}
.search-box input{
    flex:1;border:none;outline:none;background:transparent;font:inherit;font-size:17px;
    padding:14px 0;color:var(--ink);
}
.search-box input::placeholder{color:var(--faint)}
.kbd{font-size:11px;color:var(--faint);border:1px solid var(--border);border-radius:6px;padding:2px 8px;white-space:nowrap}
.spinner{
    width:20px;height:20px;border-radius:50%;flex-shrink:0;
    border:2.5px solid var(--accent-soft);border-top-color:var(--accent);
    animation:spin .7s linear infinite;display:none;
}
.searching .spinner{display:block}
@keyframes spin{to{transform:rotate(360deg)}}

/* ===== التبويبات ===== */
.tabs{display:flex;gap:8px;overflow-x:auto;padding:16px 2px 6px;scrollbar-width:none}
.tabs::-webkit-scrollbar{display:none}
.tab{
    flex-shrink:0;border:1px solid var(--border);background:var(--surface);
    color:var(--muted);border-radius:999px;padding:8px 18px;font:inherit;font-size:14px;
    cursor:pointer;transition:all .2s;white-space:nowrap;
}
.tab:hover{border-color:var(--accent);color:var(--accent)}
.tab.active{background:var(--ink);border-color:var(--ink);color:#F5F3EE}
.tab .cnt{font-size:11px;opacity:.65;margin-inline-start:6px}

/* ===== الإحصاءات ===== */
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:18px 0 24px}
.stat{
    background:var(--surface);border:1px solid var(--border);border-radius:14px;
    padding:16px 18px;box-shadow:var(--shadow);
}
.stat b{display:block;font-size:26px;font-weight:700;color:var(--accent);line-height:1.2}
.stat span{font-size:12.5px;color:var(--muted)}

/* ===== الجدول ===== */
.results-head{display:flex;align-items:baseline;justify-content:space-between;margin:8px 0 12px;gap:10px;flex-wrap:wrap}
.results-head h2{font-size:16px;font-weight:600}
.results-head .hint{font-size:12.5px;color:var(--faint)}
.table-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow);overflow:hidden}
.table-scroll{overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:14.5px;min-width:640px}
thead th{
    background:var(--surface-2);color:var(--muted);font-weight:600;font-size:13px;
    text-align:right;padding:13px 16px;border-bottom:1px solid var(--border);
    position:sticky;top:0;white-space:nowrap;
}
tbody td{padding:12px 16px;border-bottom:1px solid #F0EBE2;vertical-align:top}
tbody tr{transition:background .15s}
tbody tr:hover{background:var(--surface-2)}
tbody tr:last-child td{border-bottom:none}
mark{background:var(--accent-soft);color:var(--accent-deep);border-radius:4px;padding:0 3px;font-weight:600}
.src-badge{
    display:inline-block;font-size:11px;background:var(--accent-soft);color:var(--accent-deep);
    border-radius:6px;padding:1px 8px;font-weight:600;white-space:nowrap;
}

/* ===== حالات فارغة ===== */
.empty{padding:70px 20px;text-align:center;color:var(--faint)}
.empty svg{width:54px;height:54px;margin-bottom:14px;opacity:.4}
.empty p{font-size:15px}

footer{margin:44px 0 30px;text-align:center;color:var(--faint);font-size:12.5px}
footer b{color:var(--muted)}

/* ===== الجوال: تحويل الجدول لبطاقات ===== */
@media (max-width:640px){
    header{padding:26px 0 18px}
    .table-scroll{overflow-x:visible}
    table{min-width:0}
    thead{display:none}
    tbody tr{
        display:block;border:1px solid var(--border);border-radius:14px;
        margin:12px;padding:6px 4px;background:var(--surface-2);
    }
    tbody td{display:flex;justify-content:space-between;align-items:flex-start;gap:14px;border:none;padding:9px 12px;font-size:14px}
    tbody td::before{
        content:attr(data-label);font-size:12px;color:var(--faint);
        font-weight:600;white-space:nowrap;padding-top:2px;
    }
    tbody td:empty::after{content:'—';color:var(--faint)}
    .kbd{display:none}
}
</style>
</head>
<body>
<div class="wrap">

<header>
    <div class="brand">
        <div class="logo">
            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
        </div>
        <div>
            <h1>سجلات معتقلين</h1>
            <p>قاعدة بيانات السجلات</p>
        </div>
    </div>

    <div class="search-shell" id="shell">
        <div class="search-box">
            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
            <input id="q" type="search" autocomplete="off" spellcheck="false"
                   placeholder="ابحث بالاسم، اسم الأم، السنة، الجنسية…">
            <div class="spinner"></div>
            <span class="kbd">يبحث تلقائياً</span>
        </div>
    </div>

    <nav class="tabs" id="tabs"></nav>
</header>

<section class="stats" id="stats"></section>

<div class="results-head">
    <h2 id="resTitle">كل السجلات</h2>
    <span class="hint" id="resHint"></span>
</div>

<div class="table-card" id="card">
    <div class="table-scroll" id="tableWrap"></div>
    <div class="empty" id="empty" hidden>
        <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/><path d="M8 11h6"/></svg>
        <p>لا توجد نتائج مطابقة — جرّب كلمة أخرى</p>
    </div>
</div>

<footer>
    إجمالي <b id="footTotal">…</b> سجلاً · الزيارات: <b><?= number_format($visits) ?></b>
</footer>

</div>

<script>window.VISITS = <?= (int)$visits ?>;</script>
<script>
const $ = s => document.querySelector(s);
let META = null, scope = 'all', timer = null, lastQ = null;

const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const highlight = (text, q) => {
    if (!q) return esc(text);
    const safe = q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return esc(text).replace(new RegExp('(' + safe + ')', 'gi'), '<mark>$1</mark>');
};

async function loadMeta() {
    META = await (await fetch('?api=meta')).json();
    // التبويبات
    const tabs = [['all','كل السجلات', META.total]];
    for (const [k,v] of Object.entries(META)) if (k !== 'total') tabs.push([k, v.title, v.count]);
    $('#tabs').innerHTML = tabs.map(([k,t,c]) =>
        `<button class="tab ${k===scope?'active':''}" data-t="${k}">${esc(t)}<span class="cnt">${c.toLocaleString('ar-EG')}</span></button>`).join('');
    // الإحصاءات
    $('#stats').innerHTML = `
        <div class="stat"><b>${META.total.toLocaleString('ar-EG')}</b><span>إجمالي السجلات</span></div>
        <div class="stat"><b>${Object.keys(META).length - 1}</b><span>قاعدة بيانات فرعية</span></div>
        <div class="stat"><b>${(META.daesh_souriyin.count + META.majalin.count).toLocaleString('ar-EG')}</b><span>السوريون والمعتقلون</span></div>
        <div class="stat"><b>${(META.total - META.daesh_souriyin.count - META.majalin.count).toLocaleString('ar-EG')}</b><span>الجنسيات الأخرى</span></div>
        <div class="stat"><b>${(window.VISITS ?? 0).toLocaleString('ar-EG')}</b><span>عدد الزيارات</span></div>`;
    $('#footTotal').textContent = META.total.toLocaleString('ar-EG');
}

function columnsFor(scopeKey) {
    if (scopeKey === 'all') return ['الرقم','الاسم الثلاثي','اسم الأم','مكان وتاريخ الولادة','الجنسية','معلومات أخرى','الكود'];
    return META[scopeKey].columns;
}

function render(data, q) {
    const { rows, found, ms } = data;
    $('#resHint').textContent = found
        ? `${found.toLocaleString('ar-EG')} نتيجة · ${ms} ms`
        : '';
    const empty = $('#empty'), wrap = $('#tableWrap');
    if (!rows.length) { empty.hidden = false; wrap.innerHTML = ''; return; }
    empty.hidden = true;

    const cols = columnsFor(scope);
    let html = '<table><thead><tr>';
    if (scope === 'all') html += '<th>المصدر</th>';
    html += cols.map(c => `<th>${esc(c)}</th>`).join('') + '</tr></thead><tbody>';
    for (const r of rows) {
        html += '<tr>';
        if (scope === 'all') {
            const src = META[r.__table] ? META[r.__table].title : r.__table;
            html += `<td><span class="src-badge">${esc(src)}</span></td>`;
        }
        for (const c of cols) html += `<td data-label="${esc(c)}">${highlight(r[c] ?? '', q)}</td>`;
        html += '</tr>';
    }
    wrap.innerHTML = html + '</tbody></table>';
}

async function doSearch() {
    const q = $('#q').value.trim();
    if (q === lastQ) return;
    lastQ = q;
    $('#shell').classList.add('searching');
    try {
        const data = await (await fetch(`?api=search&q=${encodeURIComponent(q)}&t=${scope}`)).json();
        render(data, q);
    } finally { $('#shell').classList.remove('searching'); }
}

$('#q').addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(doSearch, 220); });
$('#tabs').addEventListener('click', e => {
    const b = e.target.closest('.tab'); if (!b) return;
    scope = b.dataset.t;
    document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t === b));
    $('#resTitle').textContent = b.childNodes[0].textContent.trim();
    lastQ = null; doSearch();
});
document.addEventListener('keydown', e => { if (e.key === '/' && document.activeElement !== $('#q')) { e.preventDefault(); $('#q').focus(); } });

loadMeta().then(doSearch);
</script>
</body>
</html>
